package com.ndroc.rocmovies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RocmoviesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RocmoviesApplication.class, args);
	}

}
